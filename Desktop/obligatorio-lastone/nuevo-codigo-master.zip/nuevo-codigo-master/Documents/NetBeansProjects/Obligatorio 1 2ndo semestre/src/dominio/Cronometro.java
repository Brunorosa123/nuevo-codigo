/*

 */
package dominio;


public class Cronometro {
    
}
