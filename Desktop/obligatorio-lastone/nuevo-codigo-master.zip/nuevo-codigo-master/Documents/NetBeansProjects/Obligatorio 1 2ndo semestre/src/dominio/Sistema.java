/*

 */
package dominio;

/**
 *
 * @author brumo
 */
public class Sistema {
    
}
